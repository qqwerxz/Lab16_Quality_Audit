#!/usr/bin/env python3
"""
Лабораторная работа № 16.
Комплексный аудит качества программного продукта.

Входные файлы рядом с audit.py:
  - metrics.json
  - test-results.xml (JUnit XML)

Выходные файлы:
  - reports/report.json
  - reports/report.html
"""
from __future__ import annotations

import json
import sys
from datetime import datetime
from pathlib import Path
from xml.etree import ElementTree as ET
from html import escape

BASE_DIR = Path(__file__).resolve().parent
METRICS_FILE = BASE_DIR / "metrics.json"
XML_FILE = BASE_DIR / "test-results.xml"
REPORTS_DIR = BASE_DIR / "reports"


def read_metrics(path: Path) -> dict:
    if not path.exists():
        raise FileNotFoundError(
            f"Не найден файл {path.name}. Положите его в папку рядом с audit.py."
        )
    with path.open("r", encoding="utf-8") as file:
        data = json.load(file)
    if not isinstance(data, dict):
        raise ValueError("Файл metrics.json должен содержать JSON-объект.")
    return data


def read_test_results(path: Path) -> dict:
    if not path.exists():
        raise FileNotFoundError(
            f"Не найден файл {path.name}. Положите его в папку рядом с audit.py."
        )
    try:
        root = ET.parse(path).getroot()
    except ET.ParseError as exc:
        raise ValueError(
            f"Не удалось прочитать XML-файл {path.name}: {exc}. "
            "Проверьте, что это настоящий JUnit XML-файл."
        ) from exc

    suites = []
    if root.tag == "testsuite":
        suites = [root]
    elif root.tag == "testsuites":
        suites = list(root.iter("testsuite"))
    else:
        raise ValueError(
            "Неизвестный формат XML: ожидается корневой элемент testsuite или testsuites."
        )

    totals = {"tests": 0, "failures": 0, "errors": 0, "skipped": 0}
    suite_names = []
    for suite in suites:
        for key in totals:
            try:
                totals[key] += int(suite.attrib.get(key, "0"))
            except ValueError:
                raise ValueError(
                    f"Некорректное числовое значение атрибута {key!r} в XML."
                )
        suite_names.append(suite.attrib.get("name", "Без названия"))

    # JUnit-файлы разных инструментов могут иметь разные структуры.
    # Если totals отсутствуют в атрибутах suite, считаем testcase напрямую.
    if totals["tests"] == 0:
        cases = list(root.iter("testcase"))
        totals["tests"] = len(cases)
        totals["failures"] = sum(1 for case in cases if case.find("failure") is not None)
        totals["errors"] = sum(1 for case in cases if case.find("error") is not None)
        totals["skipped"] = sum(1 for case in cases if case.find("skipped") is not None)

    passed = max(totals["tests"] - totals["failures"] - totals["errors"] - totals["skipped"], 0)
    executed = max(totals["tests"] - totals["skipped"], 0)
    success_rate = round((passed / totals["tests"] * 100), 2) if totals["tests"] else 0.0

    return {
        **totals,
        "passed": passed,
        "executed": executed,
        "success_rate_percent": success_rate,
        "suites": suite_names,
    }


def quality_status(metrics: dict, tests: dict) -> tuple[str, list[str]]:
    notes = []
    if tests["tests"] == 0:
        notes.append("В XML-отчёте не найдено ни одного теста.")
    if tests["failures"] or tests["errors"]:
        notes.append("Обнаружены неуспешные тесты или ошибки выполнения.")
    if metrics.get("known_bugs", 0):
        notes.append(f"В метриках указано известных дефектов: {metrics['known_bugs']}.")
    if tests["tests"] and tests["failures"] == 0 and tests["errors"] == 0 and tests["skipped"] == 0 and not metrics.get("known_bugs", 0):
        status = "Условно хорошее состояние по предоставленным данным"
        notes.append("Все тесты прошли; известных дефектов по входным метрикам нет.")
    else:
        status = "Требуется внимание"
    return status, notes


def build_report(metrics: dict, tests: dict) -> dict:
    status, notes = quality_status(metrics, tests)
    return {
        "report_generated_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "project_metrics": metrics,
        "test_results": tests,
        "overall_assessment": status,
        "notes": notes,
        "limitations": [
            "Вывод зависит от полноты и достоверности входных файлов.",
            "Процент успешности рассчитан как прошедшие тесты / общее число тестов.",
            "Это учебный аудит, а не полноценная сертификация качества ПО."
        ],
    }


def write_json(report: dict, path: Path) -> None:
    with path.open("w", encoding="utf-8") as file:
        json.dump(report, file, ensure_ascii=False, indent=4)


def write_html(report: dict, path: Path) -> None:
    metrics = report["project_metrics"]
    tests = report["test_results"]
    notes = report["notes"]
    notes_html = "".join(f"<li>{escape(str(note))}</li>" for note in notes) or "<li>Замечаний нет.</li>"
    metric_rows = "".join(
        f"<tr><th>{escape(str(key))}</th><td>{escape(str(value))}</td></tr>"
        for key, value in metrics.items()
    )
    html_doc = f"""<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Отчёт аудита качества ПО</title>
<style>
body {{ font-family: Arial, sans-serif; max-width: 1000px; margin: 35px auto; padding: 0 18px; color: #222; line-height: 1.5; }}
h1, h2 {{ color: #17365d; }}
.summary {{ background: #eef4fb; border-left: 5px solid #4472c4; padding: 14px 18px; margin: 20px 0; }}
table {{ border-collapse: collapse; width: 100%; margin-bottom: 24px; }}
th, td {{ border: 1px solid #ccc; padding: 9px; text-align: left; }}
th {{ background: #f2f2f2; }}
small {{ color: #555; }}
</style>
</head>
<body>
<h1>Сводный отчёт аудита качества программного продукта</h1>
<p><small>Дата формирования: {escape(report["report_generated_at"])}</small></p>
<div class="summary">
<strong>Общая оценка:</strong> {escape(report["overall_assessment"])}<br>
<strong>Успешность тестирования:</strong> {tests["success_rate_percent"]}%<br>
<strong>Всего тестов:</strong> {tests["tests"]}; успешно: {tests["passed"]}; неуспешно: {tests["failures"]}; ошибок: {tests["errors"]}; пропущено: {tests["skipped"]}.
</div>
<h2>1. Метрики проекта</h2>
<table><thead><tr><th>Показатель</th><th>Значение</th></tr></thead><tbody>{metric_rows}</tbody></table>
<h2>2. Замечания аудита</h2>
<ul>{notes_html}</ul>
<h2>3. Ограничения</h2>
<ul>{''.join(f'<li>{escape(str(item))}</li>' for item in report["limitations"])}</ul>
</body>
</html>"""
    path.write_text(html_doc, encoding="utf-8")


def main() -> int:
    try:
        metrics = read_metrics(METRICS_FILE)
        tests = read_test_results(XML_FILE)
        report = build_report(metrics, tests)
        REPORTS_DIR.mkdir(parents=True, exist_ok=True)
        write_json(report, REPORTS_DIR / "report.json")
        write_html(report, REPORTS_DIR / "report.html")
        print("Аудит завершён успешно.")
        print(f"Проект: {metrics.get('project_name', 'не указано')}")
        print(f"Тестов всего: {tests['tests']}; успешно: {tests['passed']}; "
              f"провалено: {tests['failures']}; ошибок: {tests['errors']}; "
              f"пропущено: {tests['skipped']}")
        print(f"Успешность тестирования: {tests['success_rate_percent']}%")
        print(f"Общая оценка: {report['overall_assessment']}")
        print(f"HTML-отчёт: {REPORTS_DIR / 'report.html'}")
        print(f"JSON-отчёт: {REPORTS_DIR / 'report.json'}")
        return 0
    except (OSError, json.JSONDecodeError, ValueError) as exc:
        print(f"Ошибка аудита: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
